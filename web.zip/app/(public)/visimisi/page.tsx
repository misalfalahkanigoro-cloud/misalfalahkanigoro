import React from 'react';
import { CheckCircle2, Target } from 'lucide-react';
import prisma from '@/lib/prisma';

type VisionMission = {
    id: string;
    visionText: string;
    missionText: string;
};

const splitLines = (text: string) =>
    text
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean);

const getVisionMission = async (): Promise<VisionMission | null> => {
    const data = await prisma.vision_mission_page.findFirst({
        where: { is_active: true },
        orderBy: { created_at: 'desc' },
    });

    if (!data) return null;

    return {
        id: data.id,
        visionText: data.vision_text,
        missionText: data.mission_text,
    };
};

const VisiMisiPage = async () => {
    const data = await getVisionMission();
    const missionLines = splitLines(data?.missionText || '');
    const showMissionList = missionLines.length > 1;

    return (
        <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-amber-50 dark:from-[#0A0F0B] dark:via-[#0B120E] dark:to-[#111A14] transition-colors duration-200 pb-16">
            <section className="border-b border-emerald-100/70 bg-white/80 backdrop-blur dark:border-white/10 dark:bg-[#0B0F0C]/80">
                <div className="container mx-auto px-4 py-8 md:py-10">
                    <div className="flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-emerald-700/70 dark:text-emerald-200/70">
                        <span className="h-[2px] w-8 bg-emerald-500/70"></span>
                        Halaman
                    </div>
                    <h1 className="mt-3 text-2xl md:text-4xl font-bold text-emerald-950 dark:text-white">Visi & Misi</h1>
                </div>
            </section>

            <section className="container mx-auto px-4 py-16">
                {!data ? (
                    <div className="rounded-3xl border border-dashed border-emerald-200 bg-white/80 p-10 text-center text-sm text-emerald-900/70 shadow-sm dark:border-white/10 dark:bg-white/5 dark:text-emerald-100/70">
                        Visi dan misi belum tersedia.
                    </div>
                ) : (
                    <div className="grid gap-8 lg:grid-cols-2">
                        <div className="rounded-3xl border border-emerald-100 bg-white/90 p-8 shadow-lg shadow-emerald-100/40 backdrop-blur dark:border-white/10 dark:bg-white/5">
                            <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-200">
                                <Target size={18} />
                                <span className="text-xs font-semibold uppercase tracking-[0.3em]">Visi</span>
                            </div>
                            <h2 className="mt-3 text-2xl font-semibold text-emerald-900 dark:text-white">Visi Madrasah</h2>
                            <p className="mt-4 text-gray-600 dark:text-gray-300 whitespace-pre-line">
                                {data.visionText || 'Visi belum tersedia.'}
                            </p>
                        </div>

                        <div className="rounded-3xl border border-amber-100 bg-white/90 p-8 shadow-lg shadow-amber-100/40 backdrop-blur dark:border-white/10 dark:bg-white/5">
                            <div className="flex items-center gap-2 text-amber-700 dark:text-amber-200">
                                <CheckCircle2 size={18} />
                                <span className="text-xs font-semibold uppercase tracking-[0.3em]">Misi</span>
                            </div>
                            <h2 className="mt-3 text-2xl font-semibold text-amber-900 dark:text-white">Misi Madrasah</h2>
                            {showMissionList ? (
                                <ul className="mt-4 space-y-3 text-gray-600 dark:text-gray-300">
                                    {missionLines.map((line, index) => (
                                        <li key={`${index}-${line}`} className="flex items-start gap-3">
                                            <span className="mt-2 h-2.5 w-2.5 rounded-full bg-emerald-500" />
                                            <span className="flex-1">{line}</span>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <p className="mt-4 text-gray-600 dark:text-gray-300 whitespace-pre-line">
                                    {data.missionText || 'Misi belum tersedia.'}
                                </p>
                            )}
                        </div>
                    </div>
                )}
            </section>
        </div>
    );
};

export default VisiMisiPage;
